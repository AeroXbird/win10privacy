This is a very simple tool designed to disable telemetry in Windows 10 and disable Diagnostic services in Windows 10.
It does nothing you cannot do on your own using regedit, but to make it easy for less experienced users this tool will do all that.

RUN AS ADMIN!

You MUST run this tool as Administrator because it makes changes in the registry.